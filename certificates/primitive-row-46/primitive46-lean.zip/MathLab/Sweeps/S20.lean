import MathLab.ProbeCover
namespace MathLab.Mass46
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 20000000

theorem sweep_20 : blockCheck blocks[20]! = true := by cbv
end MathLab.Mass46
