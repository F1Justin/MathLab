import MathLab.Physical

namespace MathLab.Mass46

def disp (p : Probe) : ℤ := (p.2.1:ℤ)-T
def numerator (p : Probe) (q : Nat) := (q*p.1)/D
def row (p : Probe) (q : Nat) : Prop :=
  2 ≤ q ∧ q ≤ 46 ∧ q%2 = 0 ∧ numerator p q < q ∧
  (numerator p q).gcd (q/2) = 1 ∧ q*p.1 = numerator p q * D ∧
  (q:ℤ)*|disp p| ≤ (T:ℤ)
instance (p : Probe) (q : Nat) : Decidable (row p q) :=
  inferInstanceAs (Decidable (_ ∧ _ ∧ _ ∧ _ ∧ _ ∧ _ ∧ _))
def freeCheck (v : Nat) (p : Probe) :=
  decide ((v*p.1)%D ≠ 0 ∨ (T:ℤ) < (v:ℤ)*|disp p|)
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 20000000

def witnessQ (p : Probe) := Nat.lcm 2 (D / Nat.gcd D p.1)

theorem row_certificate :
    probes.all (fun p => decide (row p (witnessQ p))) = true := by decide +kernel

theorem tail_slopes : probes.all (fun p => decide ((T:ℤ) < 80*|disp p|)) = true := by cbv

theorem free_even_certificate : (List.range 16).all (fun j =>
    probes.all (freeCheck (48+2*j))) = true := by cbv

theorem free_misses {p : Probe} (hp : p ∈ probes) (v : Nat)
    (hv : 46 < v) (he : v%2 = 0) : ¬ Witness v 0 0 (center p) (slope p) := by
  rintro ⟨⟨k,hk⟩,hs⟩
  have residue := common_residue v 0 p.1 0 k 0 hk (by simp)
  simp at residue
  have bound : (v:ℤ)*|disp p| ≤ (T:ℤ) := by
    simp only [slope,add_zero,abs_mul,abs_of_nonneg (Nat.cast_nonneg v : (0:ℝ) ≤ _),
      abs_div,abs_of_nonneg (Nat.cast_nonneg T : (0:ℝ) ≤ _)] at hs
    have ht : (0:ℝ) < T := by norm_num [T]
    rw [← mul_div_assoc,div_le_iff₀ ht,one_mul] at hs
    unfold disp
    exact_mod_cast hs
  by_cases small : v < 80
  · let j := (v-48)/2
    have hj : j < 16 := by dsimp [j]; omega
    have eq : v = 48+2*j := by dsimp [j]; omega
    have ok := List.all_eq_true.mp (List.all_eq_true.mp free_even_certificate j
      (List.mem_range.mpr hj)) p hp
    rw [← eq] at ok
    exact (of_decide_eq_true ok).elim (fun h => h residue) (fun h => (not_lt_of_ge bound) h)
  · have strict := of_decide_eq_true (List.all_eq_true.mp tail_slopes p hp)
    have large : (80:ℤ) ≤ v := by exact_mod_cast (by omega : 80 ≤ v)
    exact (not_lt_of_ge bound) (strict.trans_le (mul_le_mul_of_nonneg_right large (abs_nonneg _)))

/-- Every primitive row has a track, for all of its real slopes. Large even speeds
may assist for free at zero phase. The tracks counted here have distinct speeds. -/
def RowCover (tracks : Finset Nat) (a h : Nat → ℝ) : Prop :=
  ∀ q : Nat, 2 ≤ q → q ≤ 46 → q%2 = 0 → ∀ k : Nat, k < q →
    k.gcd (q/2) = 1 → ∀ x : ℝ, |(q:ℝ)*x| ≤ 1 →
    (∃ v ∈ tracks, Witness v (a v) (h v) ((k:ℝ)/q) x) ∨
    (∃ v : Nat, 46 < v ∧ v%2 = 0 ∧ Witness v 0 0 ((k:ℝ)/q) x)

theorem rowcover_to_probes {tracks : Finset Nat} {a h : Nat → ℝ}
    (hh : RowCover tracks a h) (p : Probe) (hp : p ∈ probes) :
    ∃ v ∈ tracks, Witness v (a v) (h v) (center p) (slope p) := by
  let q := witnessQ p
  have valid : decide (row p q) = true := List.all_eq_true.mp row_certificate p hp
  obtain ⟨hq,hq',even,hk,prim,ratio,small⟩ := of_decide_eq_true valid
  have hd : (D:ℝ) ≠ 0 := by norm_num [D]
  have hn : (q:ℝ) ≠ 0 := by exact_mod_cast (by omega : q ≠ 0)
  have ec : center p = ((numerator p q:Nat):ℝ)/q := by
    unfold center
    apply (div_eq_div_iff hd hn).mpr
    rw [mul_comm]
    exact_mod_cast ratio
  have hs : |(q:ℝ)*slope p| ≤ 1 := by
    have ht : (0:ℝ) < T := by norm_num [T]
    simp only [slope,abs_mul,abs_div,abs_of_nonneg (Nat.cast_nonneg q : (0:ℝ) ≤ _),
      abs_of_nonneg ht.le,← mul_div_assoc,div_le_iff₀ ht,one_mul]
    unfold disp at small
    exact_mod_cast small
  have cases := hh q hq hq' even _ hk prim (slope p) hs
  rw [← ec] at cases
  rcases cases with yes | ⟨v,hv,he,hit⟩
  · exact yes
  · exact False.elim (free_misses hp v hv he hit)
end MathLab.Mass46
