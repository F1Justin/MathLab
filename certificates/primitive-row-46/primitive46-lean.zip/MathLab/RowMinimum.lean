import MathLab.Primitive

namespace MathLab.Mass46

theorem row_lower_bound_of_sweeps (checked : blocks.toList.all blockCheck = true)
    (tracks : Finset Nat) (a h : Nat → ℝ)
    (hv : ∀ v ∈ tracks, 0 < v ∧ (v % 2 ≠ 0 ∨ v ≤ 46))
    (cover : RowCover tracks a h) : 23 ≤ tracks.card := by
  classical
  choose r hr using fun v => physical_to_grid v (a v) (h v)
  apply twenty_three_of_sweeps checked tracks r (fun v => (T:ℝ)*h v-(v:ℝ)*T) hv
  intro p hp
  obtain ⟨v,mem,hit⟩ := rowcover_to_probes cover p hp
  exact ⟨v,mem,hr v p hp hit⟩

def baseline : Finset Nat := (Finset.range 23).image (fun j => 2*(j+1))
theorem baseline_size : baseline.card = 23 := by decide

theorem baseline_admissible : ∀ v ∈ baseline, 0 < v ∧ (v % 2 ≠ 0 ∨ v ≤ 46) := by
  intro v hv
  obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hv
  have hj' := Finset.mem_range.mp hj
  omega

theorem baseline_covers : RowCover baseline (fun _ => 0) (fun _ => 0) := by
  intro q hlo hhi even k _ _ x hx
  have hn : (q:ℝ) ≠ 0 := by exact_mod_cast (by omega : q ≠ 0)
  left
  refine ⟨q, Finset.mem_image.mpr ⟨q/2-1, Finset.mem_range.mpr (by omega), by omega⟩, ?_⟩
  constructor
  · exact ⟨(k:ℤ), by push_cast; field_simp <;> simp⟩
  · simpa using hx

#print axioms row_lower_bound_of_sweeps
#print axioms baseline_covers
end MathLab.Mass46
