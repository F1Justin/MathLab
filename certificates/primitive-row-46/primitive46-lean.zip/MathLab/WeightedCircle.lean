import Mathlib.Algebra.Order.Archimedean.Real.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

open scoped BigOperators

namespace WeightedCircle

variable {α : Type*}

/-! ## Geometry-independent weighted double counting -/

/-- Weight of a list, counting occurrences. -/
def mass (w : α → ℕ) : List α → ℕ
  | [] => 0
  | p :: ps => w p + mass w ps

/-- Weight credited to a predicate at one probe. No decidability
assumption is needed on the actual geometric covering relation. -/
noncomputable def credit (w : α → ℕ) (P : α → Prop) (p : α) : ℕ := by
  classical
  exact if P p then w p else 0

/-- Total weight credited to a single track. -/
noncomputable def load (w : α → ℕ) (P : α → Prop) (ps : List α) : ℕ :=
  mass (credit w P) ps

/-- Multiple coverage is allowed: it can only increase the RHS. -/
theorem total_le_sum_load
    (ps : List α) (w : α → ℕ) (tracks : Finset ℕ)
    (hit : ℕ → α → Prop)
    (hcover : ∀ p ∈ ps, ∃ v ∈ tracks, hit v p) :
    mass w ps ≤ ∑ v ∈ tracks, load w (hit v) ps := by
  classical
  induction ps with
  | nil =>
      simp [mass, load]
  | cons p ps ih =>
      obtain ⟨v, hv, hhit⟩ := hcover p (by simp)
      have hone : w p ≤ ∑ u ∈ tracks, credit w (hit u) p := by
        calc
          w p = credit w (hit v) p := by simp [credit, hhit]
          _ ≤ ∑ u ∈ tracks, credit w (hit u) p :=
            Finset.single_le_sum
              (fun u _ => Nat.zero_le (credit w (hit u) p)) hv
      have hrest := ih (fun y hy => hcover y (by simp [hy]))
      simpa only [load, mass, Finset.sum_add_distrib] using
        (add_le_add hone hrest)

/-- Distinct track speeds, a common unit budget, and at most one premium
per exceptional speed. The capacity evidence can come from anywhere. -/
theorem weighted_obstruction
    (ps : List α) (w : α → ℕ)
    (tracks exc : Finset ℕ) (hit : ℕ → α → Prop)
    (unit : ℕ) (bonus cap : ℕ → ℕ)
    (hcover : ∀ p ∈ ps, ∃ v ∈ tracks, hit v p)
    (hsound : ∀ v ∈ tracks, load w (hit v) ps ≤ cap v)
    (hbudget : ∀ v ∈ tracks,
      cap v ≤ unit + (if v ∈ exc then bonus v else 0)) :
    mass w ps ≤ tracks.card * unit + ∑ v ∈ exc, bonus v := by
  classical
  have hprem :
      (∑ v ∈ tracks, if v ∈ exc then bonus v else 0) ≤
        ∑ v ∈ exc, bonus v := by
    calc
      (∑ v ∈ tracks, if v ∈ exc then bonus v else 0) =
          ∑ v ∈ tracks.filter (fun v => v ∈ exc), bonus v := by
            rw [Finset.sum_filter]
      _ ≤ ∑ v ∈ exc, bonus v := by
        apply Finset.sum_le_sum_of_subset_of_nonneg
        · intro v hv
          exact (Finset.mem_filter.mp hv).2
        · intro v _ _
          exact Nat.zero_le _
  calc
    mass w ps ≤ ∑ v ∈ tracks, load w (hit v) ps :=
      total_le_sum_load ps w tracks hit hcover
    _ ≤ ∑ v ∈ tracks, (unit + (if v ∈ exc then bonus v else 0)) :=
      Finset.sum_le_sum (fun v hv => (hsound v hv).trans (hbudget v hv))
    _ = tracks.card * unit +
        (∑ v ∈ tracks, if v ∈ exc then bonus v else 0) := by
      simp [Finset.sum_add_distrib, nsmul_eq_mul]
    _ ≤ tracks.card * unit + ∑ v ∈ exc, bonus v :=
      add_le_add (le_refl _) hprem

/-! ## A computable weighted interval sweep

At a real cut `q`, an event contributes iff its natural key is at most
`q`. An interval contributes `+w` at its left endpoint and `-w` at its
exclusive right endpoint.
-/

namespace EndpointSweep

structure Event where
  key : ℕ
  delta : ℤ

def events (w left : α → ℕ) (gap : ℕ) : List α → List Event
  | [] => []
  | p :: ps =>
      ⟨left p, (w p : ℤ)⟩ ::
      ⟨left p + gap, -(w p : ℤ)⟩ ::
      events w left gap ps

/-- Specification only; the executable never compares real numbers. -/
noncomputable def value (q : ℝ) : List Event → ℤ
  | [] => 0
  | e :: es =>
      (if (e.key : ℝ) ≤ q then e.delta else 0) + value q es

private theorem value_perm (q : ℝ) {xs ys : List Event}
    (hp : xs.Perm ys) : value q xs = value q ys := by
  induction hp with
  | nil => rfl
  | cons e _ ih => simp only [value, ih]
  | swap a b es =>
      simp only [value]
      ac_rfl
  | trans _ _ ih₁ ih₂ => exact ih₁.trans ih₂

/-- Any selected subcollection whose intervals contain `q` has weight
at most the value at `q`. Unselected intervals contribute either zero
or a nonnegative weight. -/
theorem load_le_value
    (w left : α → ℕ) (gap : ℕ) (q : ℝ)
    (P : α → Prop) (ps : List α)
    (H : ∀ p ∈ ps, P p →
      (left p : ℝ) ≤ q ∧ q < ((left p + gap : ℕ) : ℝ)) :
    (load w P ps : ℤ) ≤ value q (events w left gap ps) := by
  classical
  induction ps with
  | nil =>
      simp [load, mass, events, value]
  | cons p ps ih =>
      have htail := ih (fun y hy => H y (by simp [hy]))
      have hone :
          (credit w P p : ℤ) ≤
            (if (left p : ℝ) ≤ q then (w p : ℤ) else 0) +
            (if ((left p + gap : ℕ) : ℝ) ≤ q then -(w p : ℤ) else 0) := by
        by_cases hP : P p
        · obtain ⟨ha, hb⟩ := H p (by simp) hP
          simp only [credit, if_pos hP, if_pos ha, if_neg (not_le.mpr hb),
            add_zero, le_refl]
        · have hn : left p ≤ left p + gap := by omega
          have hr : (left p : ℝ) ≤ ((left p + gap : ℕ) : ℝ) := by
            exact_mod_cast hn
          by_cases hb : ((left p + gap : ℕ) : ℝ) ≤ q
          · simp only [credit, if_neg hP, if_pos hb, if_pos (hr.trans hb)] <;>
              omega
          · by_cases ha : (left p : ℝ) ≤ q
            · simp only [credit, if_neg hP, if_neg hb, if_pos ha] <;> omega
            · simp only [credit, if_neg hP, if_neg hb, if_neg ha] <;> omega
      simpa only [load, mass, Nat.cast_add, events, value, add_assoc] using
        (add_le_add hone htail)

structure Sweep where
  hi : ℕ
  total : ℤ
  peak : ℤ

/-- On ordered input the candidate for a new peak is just `total + delta`.
The other branch is a conservative bound even on unordered input. This
lets the soundness argument use only the permutation property of sorting. -/
def advance (s : Sweep) (e : Event) : Sweep where
  hi := max s.hi e.key
  total := s.total + e.delta
  peak := max s.peak
    ((if s.hi ≤ e.key then s.total else s.peak) + e.delta)

/-- `z` is the current prefix's value at the particular cut `q`.
It is bounded by `peak`, and above all keys seen so far it is `total`. -/
private theorem scan_aux
    (q : ℝ) (es : List Event) (s : Sweep) (z : ℤ)
    (hz : z ≤ s.peak)
    (hfull : (s.hi : ℝ) ≤ q → z = s.total) :
    z + value q es ≤ (es.foldl advance s).peak := by
  induction es generalizing s z with
  | nil =>
      simpa only [value, List.foldl_nil, add_zero] using hz
  | cons e es ih =>
      let d : ℤ := if (e.key : ℝ) ≤ q then e.delta else 0
      have hb : z + d ≤ (advance s e).peak := by
        change z + d ≤ max s.peak
          ((if s.hi ≤ e.key then s.total else s.peak) + e.delta)
        by_cases he : (e.key : ℝ) ≤ q
        · have hbase :
              z ≤ (if s.hi ≤ e.key then s.total else s.peak) := by
            by_cases hk : s.hi ≤ e.key
            · have hk' : (s.hi : ℝ) ≤ (e.key : ℝ) := by exact_mod_cast hk
              rw [if_pos hk]
              exact (hfull (hk'.trans he)).le
            · simpa only [if_neg hk] using hz
          refine le_trans ?_ (le_max_right _ _)
          simpa only [d, if_pos he] using
            (add_le_add hbase (le_refl e.delta))
        · refine le_trans ?_ (le_max_left _ _)
          simpa only [d, if_neg he, add_zero] using hz
      have hf :
          ((advance s e).hi : ℝ) ≤ q → z + d = (advance s e).total := by
        intro hh
        change ((max s.hi e.key : ℕ) : ℝ) ≤ q at hh
        have hs : (s.hi : ℝ) ≤ ((max s.hi e.key : ℕ) : ℝ) := by
          exact_mod_cast (le_max_left s.hi e.key)
        have he : (e.key : ℝ) ≤ ((max s.hi e.key : ℕ) : ℝ) := by
          exact_mod_cast (le_max_right s.hi e.key)
        change z + d = s.total + e.delta
        simp only [d, if_pos (he.trans hh), hfull (hs.trans hh)]
      simpa only [List.foldl_cons, value, d, add_assoc] using
        (ih (advance s e) (z + d) hb hf)

def ordered (es : List Event) : List Event :=
  es.mergeSort (fun a b => decide (a.key ≤ b.key))

def cap (es : List Event) : ℕ :=
  (((ordered es).foldl advance ⟨0, 0, 0⟩).peak).toNat

theorem value_le_cap (q : ℝ) (es : List Event) :
    value q es ≤ (cap es : ℤ) := by
  let ss := ordered es
  let init : Sweep := ⟨0, 0, 0⟩
  have hp : ss.Perm es := by
    change (es.mergeSort (fun a b : Event => decide (a.key ≤ b.key))).Perm es
    apply List.mergeSort_perm
  have ht := scan_aux q ss init 0 (le_refl (0 : ℤ)) (by intro _; rfl)
  have hc : (ss.foldl advance init).peak ≤
      (((ss.foldl advance init).peak.toNat : ℕ) : ℤ) := by
    omega
  calc
    value q es = value q ss := (value_perm q hp).symm
    _ ≤ (ss.foldl advance init).peak := by simpa only [zero_add] using ht
    _ ≤ (cap es : ℤ) := hc

end EndpointSweep

/-! ## Phase and slope grid -/

/-- `x` is the translated natural slope coordinate. `T` is in the
same scaled units as the inequality below. A probe type can carry
arbitrary additional data, such as an identifier. -/
structure Grid (α : Type*) where
  D : ℕ
  T : ℕ
  c : α → ℕ
  x : α → ℕ
  w : α → ℕ

namespace Grid

/-- Only a necessary condition on actual hits. The real phase
coefficient enters the argument through the common residue `r`. -/
def Fits (g : Grid α) (v r : ℕ) (h : ℝ) (p : α) : Prop :=
  (v * g.c p) % g.D = r ∧
    |(v : ℝ) * (g.x p : ℝ) + h| ≤ (g.T : ℝ)

/-- Sufficient spacing to place different residue groups in disjoint
blocks on one integer axis. -/
def stride (g : Grid α) (ps : List α) (v : ℕ) : ℕ :=
  v * (ps.foldl (fun m p => max m (g.x p)) 0) + 2 * g.T + 1

def leftKey (g : Grid α) (v b : ℕ) (p : α) : ℕ :=
  2 * (((v * g.c p) % g.D) * b + v * g.x p)

/-- Executable: two events per probe, one sort, one sweep.
Starts have even keys and exclusive ends have odd keys. -/
def cap (g : Grid α) (ps : List α) (v : ℕ) : ℕ :=
  let b := g.stride ps v
  EndpointSweep.cap
    (EndpointSweep.events g.w (g.leftKey v b) (4 * g.T + 1) ps)

theorem cap_sound
    (g : Grid α) (ps : List α) (v r : ℕ) (h : ℝ) (P : α → Prop)
    (hfit : ∀ p ∈ ps, P p → g.Fits v r h p) :
    load g.w P ps ≤ g.cap ps v := by
  let b := g.stride ps v
  let q : ℝ := 2 * ((r : ℝ) * (b : ℝ) + (g.T : ℝ) - h)
  let es := EndpointSweep.events g.w (g.leftKey v b) (4 * g.T + 1) ps
  have hf : ∀ p ∈ ps, P p →
      (g.leftKey v b p : ℝ) ≤ q ∧
        q < ((g.leftKey v b p + (4 * g.T + 1) : ℕ) : ℝ) := by
    intro p hp hP
    obtain ⟨he, ha⟩ := hfit p hp hP
    obtain ⟨hlo, hhi⟩ := abs_le.mp ha
    simp only [leftKey, he, q]
    push_cast
    constructor <;> nlinarith only [hlo, hhi]
  have h₁ : (load g.w P ps : ℤ) ≤ EndpointSweep.value q es :=
    EndpointSweep.load_le_value g.w (g.leftKey v b) (4 * g.T + 1)
      q P ps hf
  have h₂ : (load g.w P ps : ℤ) ≤ (g.cap ps v : ℤ) :=
    h₁.trans (EndpointSweep.value_le_cap q es)
  exact_mod_cast h₂

/-- Per-speed finite budget check, independent of the real coefficients. -/
def accepts (g : Grid α) (ps : List α) (v bound : ℕ) : Bool :=
  decide (g.cap ps v ≤ bound)

/-- End-to-end version. Each track has its own residue and real offset,
but they must be common to all the hits of that track. -/
theorem obstruction_of_checks
    (g : Grid α) (ps : List α)
    (tracks exc : Finset ℕ) (hit : ℕ → α → Prop)
    (unit : ℕ) (bonus : ℕ → ℕ)
    (hcover : ∀ p ∈ ps, ∃ v ∈ tracks, hit v p)
    (hnecessary : ∀ v ∈ tracks, ∃ r : ℕ, ∃ h : ℝ,
      ∀ p ∈ ps, hit v p → g.Fits v r h p)
    (hcheck : ∀ v ∈ tracks,
      g.accepts ps v (unit + (if v ∈ exc then bonus v else 0)) = true) :
    mass g.w ps ≤ tracks.card * unit + ∑ v ∈ exc, bonus v := by
  apply weighted_obstruction ps g.w tracks exc hit unit bonus (g.cap ps) hcover
  · intro v hv
    obtain ⟨r, h, hf⟩ := hnecessary v hv
    exact g.cap_sound ps v r h (hit v) hf
  · intro v hv
    exact of_decide_eq_true (hcheck v hv)

end Grid
end WeightedCircle
