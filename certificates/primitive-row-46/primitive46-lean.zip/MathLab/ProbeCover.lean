import MathLab.MassObstruction

namespace MathLab.Mass46
open WeightedCircle

/-- The only finite input to this theorem is the fifty representative cut sweeps.
Each physical track has a single common intercept residue and slope offset. -/
theorem twenty_three_of_sweeps
    (checked : blocks.toList.all blockCheck = true)
    (tracks : Finset Nat) (r : Nat → Nat) (h : Nat → ℝ)
    (hv : ∀ v ∈ tracks, 0 < v ∧ (v % 2 ≠ 0 ∨ v ≤ 46))
    (cover : ∀ p ∈ probes, ∃ v ∈ tracks, (grid 1 1).Fits v (r v) (h v) p) :
    23 ≤ tracks.card := by
  classical
  let hit := fun (v : Nat) (p : Probe) => (grid 1 1).Fits v (r v) (h v) p
  let exc : Finset Nat := {6,18,315}
  have hb (i : Nat) (hi : i < blocks.size) : blockCheck blocks[i]! = true := by
    have hm : blocks[i] ∈ blocks.toList := by simp
    simpa [getElem!_pos, hi] using (List.all_eq_true.mp checked _ hm)
  have caps (v : Nat) (v_mem : v ∈ tracks) :
      load (fun p : Probe => p.2.2) (hit v) probes ≤ M + extra v := by
    obtain ⟨vpos,admissible⟩ := hv v v_mem
    have rep : ∃ (i k : Nat), i < blocks.size ∧ compatible v blocks[i]! k := by
      by_cases hsmall : v < 2689
      · have good := List.all_eq_true.mp speed_table v (List.mem_range.mpr hsmall)
        have valid : ¬ (v = 0 ∨ v % 2 = 0 ∧ 46 < v) := by omega
        obtain ⟨i,k,hc⟩ : ∃ i k, choice v = (i,k) := ⟨_,_,rfl⟩
        simp [speedCheck,valid,hc] at good
        exact ⟨i,k,good⟩
      · refine ⟨49,0,by decide,?_⟩
        change (0*v)%D = 0%D ∧ 2689 ≤ v ∧ 0 ≤ extra v
        exact ⟨by simp,by omega,Nat.zero_le _⟩
    obtain ⟨i,k,hi,hc⟩ := rep
    let b := blocks[i]!
    have bound : (grid b.factor b.speed).cap probes 1 ≤ M+b.extra :=
      of_decide_eq_true (hb i hi)
    have transfer := (grid b.factor b.speed).cap_sound probes 1 ((k*r v)%D)
      ((b.speed:ℝ)/(v:ℝ)*h v) (hit v)
      (fun p _ hh => reduce_track v (r v) k b vpos hc (h v) p hh)
    exact transfer.trans (bound.trans (Nat.add_le_add_left hc.2.2 M))
  have budget : ∀ v ∈ tracks, M + extra v ≤ M + (if v ∈ exc then extra v else 0) := by
    intro v _
    by_cases e : v ∈ exc
    · simp [e]
    · simp [exc] at e
      simp [exc,extra,e.1,e.2.1,e.2.2]
  have inequality := weighted_obstruction probes (fun p : Probe => p.2.2)
    tracks exc hit M extra (fun v => M+extra v) cover caps budget
  have sum_exc : ∑ v ∈ exc, extra v = 31020 := by decide
  rw [probe_mass,sum_exc] at inequality
  change 1425600 ≤ tracks.card * 63360 + 31020 at inequality
  omega

#print axioms twenty_three_of_sweeps
end MathLab.Mass46
