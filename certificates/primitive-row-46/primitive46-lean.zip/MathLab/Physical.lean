import MathLab.ProbeCover
import Mathlib.Data.Int.ModEq

namespace MathLab.Mass46

/-- Physical phase a and linear coefficient h in a + h δ. -/
def Witness (v : Nat) (a h c x : ℝ) : Prop :=
  (∃ k : ℤ, (v:ℝ)*c+a = k) ∧ |(v:ℝ)*x+h| ≤ 1

noncomputable def center (p : Probe) : ℝ := (p.1:ℝ)/D
noncomputable def slope (p : Probe) : ℝ := ((p.2.1:ℝ)-T)/T

theorem common_residue (v : Nat) (a : ℝ) (x y : Nat) (k l : ℤ)
    (hx : (v:ℝ)*((x:ℝ)/D)+a = k) (hy : (v:ℝ)*((y:ℝ)/D)+a = l) :
    (v*x)%D = (v*y)%D := by
  have hd : (D:ℝ) ≠ 0 := by norm_num [D]
  have he : (v:ℤ)*x-(v:ℤ)*y = (D:ℤ)*(k-l) := by
    have hh : (v:ℝ)*x-(v:ℝ)*y = (D:ℝ)*((k:ℝ)-l) := by
      field_simp [hd] at hx hy
      linarith
    exact_mod_cast hh
  have hm : ((v*x:Nat):ℤ) ≡ ((v*y:Nat):ℤ) [ZMOD (D:ℤ)] := by
    apply Int.modEq_iff_dvd.mpr
    exact ⟨l-k, by push_cast; linarith⟩
  change ((v*x:Nat):ℤ) % D = ((v*y:Nat):ℤ) % D at hm
  exact_mod_cast hm

theorem physical_to_grid (v : Nat) (a h : ℝ) :
    ∃ r : Nat, ∀ p ∈ probes, Witness v a h (center p) (slope p) →
      (grid 1 1).Fits v r ((T:ℝ)*h-(v:ℝ)*T) p := by
  classical
  by_cases ex : ∃ p ∈ probes, Witness v a h (center p) (slope p)
  · obtain ⟨q,_,⟨⟨l,hl⟩,_⟩⟩ := ex
    refine ⟨(v*q.1)%D, ?_⟩
    intro p _ hit
    obtain ⟨⟨k,hk⟩,hs⟩ := hit
    constructor
    · simpa [grid] using common_residue v a p.1 q.1 k l hk hl
    · simp only [grid,one_mul]
      have ht : (0:ℝ) < T := by norm_num [T]
      have eq : (v:ℝ)*(p.2.1:ℝ)+((T:ℝ)*h-v*T) = ((v:ℝ)*slope p+h)*T := by
        unfold slope
        field_simp
        ring
      rw [eq,abs_mul,abs_of_pos ht]
      simpa using mul_le_mul_of_nonneg_right hs ht.le
  · exact ⟨0,fun p hp hit => False.elim (ex ⟨p,hp,hit⟩)⟩
end MathLab.Mass46
