import MathLab.RowMinimum
import MathLab.Mass46Complete

namespace MathLab.Mass46

theorem sharp_minimum : IsLeast
    {m : Nat | ∃ (tracks : Finset Nat) (a h : Nat → ℝ),
      tracks.card = m ∧ (∀ v ∈ tracks, 0 < v ∧ (v%2 ≠ 0 ∨ v ≤ 46)) ∧
      RowCover tracks a h} 23 := by
  constructor
  · exact ⟨baseline, _, _, baseline_size, baseline_admissible, baseline_covers⟩
  · rintro m ⟨tracks,a,h,rfl,hv,cover⟩
    exact row_lower_bound_of_sweeps all_blocks tracks a h hv cover

#print axioms sharp_minimum
end MathLab.Mass46
