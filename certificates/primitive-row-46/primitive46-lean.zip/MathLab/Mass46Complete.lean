import MathLab.Sweeps.S00
import MathLab.Sweeps.S01
import MathLab.Sweeps.S02
import MathLab.Sweeps.S03
import MathLab.Sweeps.S04
import MathLab.Sweeps.S05
import MathLab.Sweeps.S06
import MathLab.Sweeps.S07
import MathLab.Sweeps.S08
import MathLab.Sweeps.S09
import MathLab.Sweeps.S10
import MathLab.Sweeps.S11
import MathLab.Sweeps.S12
import MathLab.Sweeps.S13
import MathLab.Sweeps.S14
import MathLab.Sweeps.S15
import MathLab.Sweeps.S16
import MathLab.Sweeps.S17
import MathLab.Sweeps.S18
import MathLab.Sweeps.S19
import MathLab.Sweeps.S20
import MathLab.Sweeps.S21
import MathLab.Sweeps.S22
import MathLab.Sweeps.S23
import MathLab.Sweeps.S24
import MathLab.Sweeps.S25
import MathLab.Sweeps.S26
import MathLab.Sweeps.S27
import MathLab.Sweeps.S28
import MathLab.Sweeps.S29
import MathLab.Sweeps.S30
import MathLab.Sweeps.S31
import MathLab.Sweeps.S32
import MathLab.Sweeps.S33
import MathLab.Sweeps.S34
import MathLab.Sweeps.S35
import MathLab.Sweeps.S36
import MathLab.Sweeps.S37
import MathLab.Sweeps.S38
import MathLab.Sweeps.S39
import MathLab.Sweeps.S40
import MathLab.Sweeps.S41
import MathLab.Sweeps.S42
import MathLab.Sweeps.S43
import MathLab.Sweeps.S44
import MathLab.Sweeps.S45
import MathLab.Sweeps.S46
import MathLab.Sweeps.S47
import MathLab.Sweeps.S48
import MathLab.Sweeps.S49
namespace MathLab.Mass46
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 20000000

theorem all_blocks : blocks.toList.all blockCheck = true := by
  have entries : blocks.toList = [blocks[0]!, blocks[1]!, blocks[2]!, blocks[3]!, blocks[4]!, blocks[5]!, blocks[6]!, blocks[7]!, blocks[8]!, blocks[9]!, blocks[10]!, blocks[11]!, blocks[12]!, blocks[13]!, blocks[14]!, blocks[15]!, blocks[16]!, blocks[17]!, blocks[18]!, blocks[19]!, blocks[20]!, blocks[21]!, blocks[22]!, blocks[23]!, blocks[24]!, blocks[25]!, blocks[26]!, blocks[27]!, blocks[28]!, blocks[29]!, blocks[30]!, blocks[31]!, blocks[32]!, blocks[33]!, blocks[34]!, blocks[35]!, blocks[36]!, blocks[37]!, blocks[38]!, blocks[39]!, blocks[40]!, blocks[41]!, blocks[42]!, blocks[43]!, blocks[44]!, blocks[45]!, blocks[46]!, blocks[47]!, blocks[48]!, blocks[49]!] := rfl
  rw [entries]
  simp only [List.all_cons, List.all_nil, sweep_0, sweep_1, sweep_2, sweep_3, sweep_4, sweep_5, sweep_6, sweep_7, sweep_8, sweep_9, sweep_10, sweep_11, sweep_12, sweep_13, sweep_14, sweep_15, sweep_16, sweep_17, sweep_18, sweep_19, sweep_20, sweep_21, sweep_22, sweep_23, sweep_24, sweep_25, sweep_26, sweep_27, sweep_28, sweep_29, sweep_30, sweep_31, sweep_32, sweep_33, sweep_34, sweep_35, sweep_36, sweep_37, sweep_38, sweep_39, sweep_40, sweep_41, sweep_42, sweep_43, sweep_44, sweep_45, sweep_46, sweep_47, sweep_48, sweep_49, Bool.true_and]

theorem concrete_probe_lower_bound_kernel
    (tracks : Finset Nat) (r : Nat → Nat) (h : Nat → ℝ)
    (hv : ∀ v ∈ tracks, 0 < v ∧ (v % 2 ≠ 0 ∨ v ≤ 46))
    (cover : ∀ p ∈ probes, ∃ v ∈ tracks, (grid 1 1).Fits v (r v) (h v) p) :
    23 ≤ tracks.card :=
  twenty_three_of_sweeps all_blocks tracks r h hv cover

#print axioms concrete_probe_lower_bound_kernel
end MathLab.Mass46
