import MathLab.MassData
import Mathlib.Data.Nat.ModEq
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace MathLab.Mass46
open WeightedCircle

/-- A modular multiplier preserves equality of residues. A slower reference
speed has a wider slope window, after a common rescaling of its real offset. -/
theorem reduce_track (v r k : Nat) (b : Block) (hv : 0 < v)
    (ok : compatible v b k) (h : ℝ) (p : Probe)
    (hit : (grid 1 1).Fits v r h p) :
    (grid b.factor b.speed).Fits 1 ((k*r)%D) ((b.speed:ℝ)/(v:ℝ)*h) p := by
  rcases ok with ⟨hm,ht,_⟩
  rcases hit with ⟨hc,hs⟩
  simp only [grid, one_mul] at hc hs
  unfold Grid.Fits
  simp only [grid, one_mul, Nat.cast_one]
  constructor
  · have hm' : k*v ≡ b.factor [MOD D] := hm
    have eq₁ := (hm'.mul_right p.1).symm
    change (b.factor*p.1)%D = (k*r)%D
    have eq₂ : v*p.1 ≡ r [MOD D] := by rw [← hc]; exact Nat.mod_modEq _ _ |>.symm
    exact eq₁.trans (by simpa only [Nat.mul_assoc] using eq₂.mul_left k)
  · have hv' : (0:ℝ) < v := by exact_mod_cast hv
    have ht' : (b.speed:ℝ) ≤ v := by exact_mod_cast ht
    let u : ℝ := (b.speed:ℝ)/(v:ℝ)
    have hu : 0 ≤ u := div_nonneg (Nat.cast_nonneg _) hv'.le
    have hu' : u ≤ 1 := (div_le_one hv').mpr ht'
    change |((b.speed*p.2.1:Nat):ℝ) + u*h| ≤ (T:ℝ)
    have he : ((b.speed*p.2.1:Nat):ℝ) + u*h =
        u*((v:ℝ)*(p.2.1:ℝ)+h) := by
      dsimp [u]; push_cast; field_simp <;> ring
    rw [he, abs_mul, abs_of_nonneg hu]
    exact (mul_le_mul_of_nonneg_left hs hu).trans
      (by simpa using mul_le_mul_of_nonneg_right hu' (Nat.cast_nonneg T))

end MathLab.Mass46
