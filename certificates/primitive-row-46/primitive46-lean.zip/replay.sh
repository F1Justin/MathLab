#!/bin/sh
set -eu
export LEAN_NUM_THREADS=1
lake exe cache get Mathlib.Data.Int.ModEq Mathlib.Data.Nat.ModEq Mathlib.Tactic.FieldSimp Mathlib.Tactic.Ring Mathlib.Tactic.Linarith Mathlib.Tactic.NormNum Mathlib.Algebra.Order.Archimedean.Real.Basic Mathlib.Algebra.Order.BigOperators.Group.Finset
lake build MathLab.RowMinimum
for file in MathLab/Sweeps/S*.lean; do
    name=$(basename "$file" .lean)
    lake build "MathLab.Sweeps.$name"
    lake env leanchecker -v "MathLab.Sweeps.$name"
done
lake build MathLab.ExactMinimum
lake env leanchecker -v MathLab.WeightedCircle MathLab.MassData MathLab.MassObstruction MathLab.ProbeCover MathLab.Physical MathLab.Primitive MathLab.RowMinimum MathLab.Mass46Complete MathLab.ExactMinimum
