import Std

namespace MathLab.ScaleCounting

/-- A pair (d,a) contributes floor((N+a)/d) hits. -/
abbrev Progression := Nat × Nat

def makeRows (m t : Nat) (residues : List Nat) : List Progression :=
  residues.map fun r => (m*t, t*(m-r))

def rows : List Progression :=
  ([96,120,216,480,600,864,1080,2400,3000,4320,5400,5832,7776] : List Nat).flatMap
    (fun t => makeRows 30 t [1,7,11,13,17,19,23,29]) ++
  ([12000,15000,21600] : List Nat).flatMap (fun t => makeRows 6 t [1,5])

def count (N : Nat) : List Progression → Nat
  | [] => 0
  | (d,a)::xs => (N+a)/d + count N xs

def guaranteed (step : Nat) : List Progression → Nat
  | [] => 0
  | (d,_)::xs => step/d + guaranteed step xs

theorem shift (N step : Nat) (xs : List Progression) :
    count N xs + guaranteed step xs ≤ count (N+step) xs := by
  induction xs with
  | nil => simp [count,guaranteed]
  | cons x xs ih =>
    obtain ⟨d,a⟩ := x
    simp only [count,guaranteed]
    have h := @Nat.div_add_div_le_add_div (N+a) step d
    rw [show N+a+step=N+step+a by omega] at h
    omega

private theorem start_checked :
    (List.range 1029).all (fun h => decide (h ≤ count (126*h) rows)) = true := by
  set_option maxRecDepth 4096 in decide +kernel

/-- For each h the certified threshold table saves at least h at N=126h. -/
theorem all_sizes (h : Nat) : h ≤ count (126*h) rows := by
  induction h using Nat.strongRecOn with
  | ind h ih =>
    by_cases hs : h < 1029
    · exact of_decide_eq_true (List.all_eq_true.mp start_checked h (List.mem_range.mpr hs))
    · have prev := ih (h-1029) (by omega)
      have step := shift (126*(h-1029)) (126*1029) rows
      have g : guaranteed (126*1029) rows = 1038 := by decide +kernel
      rw [g, show 126*(h-1029)+126*1029 = 126*h by omega] at step
      omega

end MathLab.ScaleCounting
