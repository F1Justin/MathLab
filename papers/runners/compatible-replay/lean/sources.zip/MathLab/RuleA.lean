import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Algebra.Order.Archimedean.Real.Basic

namespace RuleA

def affected : List ℕ := [8, 12, 16, 24, 32, 48, 64, 96, 192]

def Replacement (v : ℕ) (a h : ℝ) : Prop :=
  (v ∈ ([12, 24, 48, 96] : List ℕ) ∧ a = 1 / 2 ∧ h = 1 / 2) ∨
  (v ∈ ([16, 64] : List ℕ) ∧ a = 0 ∧ h = -1) ∨
  (v ∈ ([3, 9] : List ℕ) ∧ a = 1 / 4 ∧ h = 0)

private abbrev Covered (q : ℕ) (k : ℤ) (z : ℝ) : Prop :=
  ∃ (v : ℕ) (a h : ℝ) (m : ℤ),
    Replacement v a h ∧
    (v : ℝ) * (k : ℝ) / (q : ℝ) + a = (m : ℝ) ∧
    |(v : ℝ) / (q : ℝ) * z + h| ≤ 1

/-- Use the same slope `s = v/q` for the phase equation and the interval bound. -/
private theorem coverOfSlope {q v : ℕ} {k m : ℤ} {z a h s : ℝ}
    (rep : Replacement v a h)
    (slope : (v : ℝ) / (q : ℝ) = s)
    (phase : s * (k : ℝ) + a = (m : ℝ))
    (bounds : -1 ≤ s * z + h ∧ s * z + h ≤ 1) :
    Covered q k z := by
  refine ⟨v, a, h, m, rep, ?_, ?_⟩
  · calc
      (v : ℝ) * (k : ℝ) / (q : ℝ) + a =
          ((v : ℝ) / (q : ℝ)) * (k : ℝ) + a := by
            simp only [div_eq_mul_inv, mul_right_comm]
      _ = (m : ℝ) := by simpa only [slope] using phase
  · simpa only [slope] using (abs_le.mpr bounds)

/-- At `q = 12`, the two odd residues modulo four select different tracks. -/
private theorem coverTwelve {k n : ℤ} {z : ℝ}
    (hn : k = 2 * n + 1) (lo : -1 ≤ z) (hi : z ≤ 1) :
    Covered 12 k z := by
  obtain ⟨b, hb⟩ : ∃ b : ℤ, k = 4 * b + 1 ∨ k = 4 * b + 3 := by
    refine ⟨n / 2, ?_⟩
    by_cases he : n % 2 = 0
    · left
      omega
    · right
      omega
  rcases hb with hb | hb
  · have hbR : (k : ℝ) = 4 * (b : ℝ) + 1 := by exact_mod_cast hb
    refine coverOfSlope (v := 9) (s := 3 / 4) (a := 1 / 4) (h := 0)
      (m := 3 * b + 1) ?_ ?_ ?_ ?_
    · norm_num [Replacement, List.mem_cons]
    · norm_num
    · push_cast
      linarith only [hbR]
    · constructor <;> linarith only [lo, hi]
  · have hbR : (k : ℝ) = 4 * (b : ℝ) + 3 := by exact_mod_cast hb
    refine coverOfSlope (v := 3) (s := 1 / 4) (a := 1 / 4) (h := 0)
      (m := b + 1) ?_ ?_ ?_ ?_
    · norm_num [Replacement, List.mem_cons]
    · norm_num
    · push_cast
      linarith only [hbR]
    · constructor <;> linarith only [lo, hi]

theorem ruleA (q : ℕ) (hq : q ∈ affected) (k : ℤ) (hk : k % 2 = 1)
    (z : ℝ) (lo : -1 ≤ z) (hi : z ≤ 1) :
    ∃ (v : ℕ) (a h : ℝ) (m : ℤ),
      Replacement v a h ∧
      (v : ℝ) * (k : ℝ) / (q : ℝ) + a = (m : ℝ) ∧
      |(v : ℝ) / (q : ℝ) * z + h| ≤ 1 := by
  change Covered q k z
  obtain ⟨n, hn⟩ : ∃ n : ℤ, k = 2 * n + 1 := ⟨k / 2, by omega⟩
  have hnR : (k : ℝ) = 2 * (n : ℝ) + 1 := by exact_mod_cast hn

  -- Slope 1/2 with offset 1/2 works on the entire interval.
  have halfCase (d u : ℕ) (repU : Replacement u (1 / 2) (1 / 2))
      (su : (u : ℝ) / (d : ℝ) = 1 / 2) : Covered d k z := by
    refine coverOfSlope (m := n + 1) repU su ?_ ?_
    · push_cast
      linarith only [hnR]
    · constructor <;> linarith only [lo, hi]

  -- Use `u` on z ≤ 0 and `w` on z > 0.
  have signCase (d u w : ℕ)
      (repU : Replacement u (1 / 2) (1 / 2))
      (su : (u : ℝ) / (d : ℝ) = 3 / 2)
      (repW : Replacement w 0 (-1))
      (sw : (w : ℝ) / (d : ℝ) = 1 ∨ (w : ℝ) / (d : ℝ) = 2) :
      Covered d k z := by
    by_cases hz : z ≤ 0
    · refine coverOfSlope (m := 3 * n + 2) repU su ?_ ?_
      · push_cast
        linarith only [hnR]
      · constructor <;> linarith only [lo, hz]
    · have hz' : 0 ≤ z := le_of_lt (lt_of_not_ge hz)
      rcases sw with sw | sw
      · refine coverOfSlope (m := k) repW sw ?_ ?_
        · simp
        · constructor <;> linarith only [hz', hi]
      · refine coverOfSlope (m := 2 * k) repW sw ?_ ?_
        · norm_num [Int.cast_mul]
        · constructor <;> linarith only [hz', hi]

  simp only [affected, List.mem_cons, List.not_mem_nil, or_false] at hq
  rcases hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · apply signCase 8 12 16 <;> norm_num [Replacement, List.mem_cons]
  · exact coverTwelve hn lo hi
  · apply signCase 16 24 16 <;> norm_num [Replacement, List.mem_cons]
  · apply halfCase 24 12 <;> norm_num [Replacement, List.mem_cons]
  · apply signCase 32 48 64 <;> norm_num [Replacement, List.mem_cons]
  · apply halfCase 48 24 <;> norm_num [Replacement, List.mem_cons]
  · apply signCase 64 96 64 <;> norm_num [Replacement, List.mem_cons]
  · apply halfCase 96 48 <;> norm_num [Replacement, List.mem_cons]
  · apply halfCase 192 96 <;> norm_num [Replacement, List.mem_cons]

end RuleA
