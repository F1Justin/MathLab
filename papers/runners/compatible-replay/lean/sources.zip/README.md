# Lean certificates

The packaged sources are pinned to Lean 4.35.0 and Mathlib commit 56a005855ea17e0b0958f73ec801ae140b0a1679. With elan installed, run these commands in this directory.

~~~sh
lake exe cache get
lake build
lake env leanchecker --verbose MathLab.ScaleCells MathLab.LocalTransfer MathLab.Scale476 MathLab.ScaleCounting MathLab.RuleA
~~~

The endpoint `MathLab.ScaleRule.certificate476` proves that the listed configuration has 476 distinct positive integer speeds and covers every real time at radius $1/481$. The endpoint `MathLab.ScaleCounting.all_sizes` proves $h\le G(126h)$ for every natural $h$ for the literal progression data. `MathLab.LocalTransfer` is the generic bridge from a local certificate to a cover. The other fifteen recipes and the larger periodic discrepancy and infinite-layer estimate use the written proof and the exact standalone verifier.

On 27 November 2026 the same package sources matched the SHA-256 values of the pinned files on Kanako, and a fresh stock-kernel replay of the five named modules plus the earlier `MathLab.PeriodicPacking` exited successfully. The original receipt records the full build and the endpoint axioms. `PeriodicPacking` concerns the v1 integer bound, separate from the updated periodic calculation. [Original Kanako receipt](kanako-original.log)
