import MathLab.Scale476
import MathLab.ScaleCounting
import MathLab.RuleA

#print axioms MathLab.ScaleRule.certificate476
#print axioms MathLab.ScaleCounting.all_sizes
